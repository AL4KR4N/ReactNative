import { View } from "react-native";
import Signup from "@/components/Signup";
export default function SignupScreen(){
    return(
        <View>
            <Signup/>
        </View>
    );
}