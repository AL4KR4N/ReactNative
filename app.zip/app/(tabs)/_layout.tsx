import { Tabs } from "expo-router";

export default function RootLayout(){
  return(
    <Tabs>
        <Tabs.Screen name="HomeScreen"/>
        <Tabs.Screen name="AboutScreen" />
        <Tabs.Screen name="ProfileScreen"/>
    </Tabs>
  );
}