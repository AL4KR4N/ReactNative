import { View } from "react-native";
import Home from "@/components/Home";

export default function HomeScreen(){
    return(
        <View>
            <Home/>
        </View>
    );
}