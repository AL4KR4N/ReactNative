import { View } from "react-native";
import Profile from "@/components/Profile";

export default function ProfileScreen(){
    return(
        <View>
            <Profile/>
        </View>
    )
}