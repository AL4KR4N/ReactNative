import { View } from "react-native";
import About from "@/components/About";

export default function AboutScreen(){
    return(
        <View>
            <About/>
        </View>
    );
}